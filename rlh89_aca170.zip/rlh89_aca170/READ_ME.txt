To import the source code into eclipse:

	1)	Open eclipse and create a new empty java project (File -> New -> Java Project).
	2)	Expand the new project and on the src folder right click and click import. Under general select file system (or search for it). 
	3)	Click browse and find and select “source code” folder provided and click select folder.
	4)	Click the tick boxes next to all the .java files you wish to import.
	5)	Click finish
	6)	To run the program, choose run from the GameEnvironment class



To run the provided jar file:

	1)	Ensure Java14 is installed on your computer (can be installed at https://java.com/en/download/)
	2)	Open the zip folder in a terminal window
	3)	run “java -jar rlh89_aca170_IslandTrader.jar” in the terminal